export interface SimulationParams {
  capacitance: number; // in Microfarads (uF)
  resistance: number; // in Ohms (Ohm)
  initialVoltage: number; // in Volts (V)
}

export interface DataPoint {
  time: number; // seconds
  voltage: number; // Volts
  current: number; // Amps
  charge: number; // Coulombs
}

export enum SimulationState {
  IDLE = 'IDLE',
  CHARGING = 'CHARGING', // Not fully implemented physically, just resets to max V
  DISCHARGING = 'DISCHARGING',
  PAUSED = 'PAUSED',
  COMPLETE = 'COMPLETE'
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  isError?: boolean;
}