import React, { useState, useEffect, useRef, useCallback } from 'react';
import { SimulationParams, SimulationState, DataPoint } from './types';
import CircuitVisualizer from './components/CircuitVisualizer';
import DischargeChart from './components/DischargeChart';
import ControlPanel from './components/ControlPanel';
import LabAssistant from './components/LabAssistant';
import { Activity } from 'lucide-react';

const INITIAL_PARAMS: SimulationParams = {
  capacitance: 470, // uF
  resistance: 1000, // Ohms
  initialVoltage: 12, // V
};

const SIMULATION_STEP_MS = 16; // ~60fps

export default function App() {
  const [params, setParams] = useState<SimulationParams>(INITIAL_PARAMS);
  const [state, setState] = useState<SimulationState>(SimulationState.IDLE);
  const [currentTime, setCurrentTime] = useState(0);
  const [data, setData] = useState<DataPoint[]>([]);
  
  // Physics Calculation Ref (to avoid dependency loops in interval)
  const paramsRef = useRef(params);
  const startTimeRef = useRef<number | null>(null);
  const animationFrameRef = useRef<number>();
  const pausedTimeRef = useRef<number>(0);

  // Update ref when params change
  useEffect(() => {
    paramsRef.current = params;
    // If idle, reset the preview voltage
    if (state === SimulationState.IDLE) {
       // Optional: Could show initial state preview here
    }
  }, [params, state]);

  // Derived Values
  const timeConstant = (params.resistance * params.capacitance) / 1000000; // Tau = RC (seconds)
  const currentVoltage = state === SimulationState.IDLE 
    ? params.initialVoltage 
    : (data.length > 0 ? data[data.length - 1].voltage : params.initialVoltage);

  // Simulation Logic
  const updateSimulation = useCallback((timestamp: number) => {
    if (!startTimeRef.current) startTimeRef.current = timestamp;
    
    // Calculate elapsed time taking pauses into account
    // For simplicity in this demo, we'll just increment by delta if we assume steady frame rate,
    // but using actual timestamps is more robust.
    // However, to support pause/resume easily, we might just track accumulation.
    
    // Let's use a simple accumulation model driven by the loop
    const t = currentTime + (SIMULATION_STEP_MS / 1000); 
    
    const V0 = paramsRef.current.initialVoltage;
    const R = paramsRef.current.resistance;
    const C = paramsRef.current.capacitance / 1000000; // Convert uF to F
    const tau = R * C;

    // V(t) = V0 * e^(-t/RC)
    const voltage = V0 * Math.exp(-t / tau);
    const current = voltage / R;
    const charge = C * voltage;

    const newDataPoint: DataPoint = {
      time: t,
      voltage,
      current,
      charge
    };

    setData(prev => {
      // Keep only last N points for performance if needed, but for discharge curve we usually want the whole history
      // Limit to 500 points to prevent memory leak if left running forever
      if (prev.length > 1000) return [...prev.slice(1), newDataPoint];
      return [...prev, newDataPoint];
    });

    setCurrentTime(t);

    // Stop condition: Voltage effectively 0 (e.g., < 0.1% of initial)
    if (voltage < 0.01) {
      setState(SimulationState.COMPLETE);
      return; 
    }

    animationFrameRef.current = requestAnimationFrame(() => updateSimulation(performance.now()));
  }, [currentTime]);

  const startSimulation = () => {
    if (state === SimulationState.COMPLETE) resetSimulation();
    setState(SimulationState.DISCHARGING);
  };

  const pauseSimulation = () => {
    setState(SimulationState.PAUSED);
    if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
  };

  const resetSimulation = () => {
    setState(SimulationState.IDLE);
    setCurrentTime(0);
    setData([{ time: 0, voltage: params.initialVoltage, current: params.initialVoltage/params.resistance, charge: (params.capacitance/1000000)*params.initialVoltage }]);
    if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
  };

  // Effect to drive the animation loop
  useEffect(() => {
    if (state === SimulationState.DISCHARGING) {
       // We use a timeout wrapper or just rely on the recursive RAF in updateSimulation
       // But to ensure we pass the right 't', we need to manage state carefully.
       // The recursive approach inside updateSimulation is slightly cleaner for "resume".
       // Let's just kick it off.
       animationFrameRef.current = requestAnimationFrame((ts) => updateSimulation(ts));
    }
    return () => {
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    };
  }, [state, updateSimulation]);

  // Initial data point
  useEffect(() => {
     if (data.length === 0) {
        setData([{ 
          time: 0, 
          voltage: params.initialVoltage, 
          current: params.initialVoltage/params.resistance, 
          charge: (params.capacitance/1000000)*params.initialVoltage 
        }]);
     }
  }, []);

  return (
    <div className="min-h-screen w-full flex flex-col p-4 md:p-6 font-sans text-gray-200 relative">
      {/* Top Header */}
      <header className="flex justify-between items-center mb-6 z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-neon-blue/10 border border-neon-blue flex items-center justify-center shadow-neon-glow">
            <Activity className="text-neon-blue" />
          </div>
          <div>
            <h1 className="text-2xl md:text-3xl font-display font-bold text-transparent bg-clip-text bg-gradient-to-r from-neon-blue to-neon-purple">
              CAPACITOR_VR
            </h1>
            <p className="text-xs text-gray-500 tracking-[0.3em] uppercase">Physics Simulation Environment</p>
          </div>
        </div>
        
        {/* State Indicator */}
        <div className="hidden md:flex items-center gap-4 px-4 py-2 bg-black/40 border border-gray-800 rounded-full backdrop-blur-sm">
           <div className={`w-2 h-2 rounded-full ${state === SimulationState.DISCHARGING ? 'bg-neon-green animate-pulse shadow-neon-glow' : 'bg-gray-500'}`} />
           <span className="text-xs font-mono text-gray-400">STATUS: <span className="text-white">{state}</span></span>
        </div>
      </header>

      {/* Main Grid Layout */}
      <main className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6 z-10 max-w-7xl mx-auto w-full">
        
        {/* Left Column: Visualization & Graph (8 cols) */}
        <div className="lg:col-span-8 flex flex-col gap-6">
          <CircuitVisualizer 
            voltage={currentVoltage}
            maxVoltage={params.initialVoltage}
            state={state}
            resistance={params.resistance}
            capacitance={params.capacitance}
          />
          <DischargeChart 
            data={data} 
            maxTime={Math.max(currentTime * 1.2, 5 * timeConstant)} 
          />
        </div>

        {/* Right Column: Controls (4 cols) */}
        <div className="lg:col-span-4 h-full">
          <ControlPanel 
            params={params}
            setParams={setParams}
            state={state}
            onStart={startSimulation}
            onPause={pauseSimulation}
            onReset={resetSimulation}
          />
        </div>
      </main>

      {/* AI Assistant Overlay */}
      <LabAssistant params={params} currentVoltage={currentVoltage} />
    </div>
  );
}