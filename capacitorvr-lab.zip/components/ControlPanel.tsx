import React from 'react';
import { SimulationParams, SimulationState } from '../types';
import { Play, Pause, RefreshCw, Zap } from 'lucide-react';

interface ControlPanelProps {
  params: SimulationParams;
  setParams: React.Dispatch<React.SetStateAction<SimulationParams>>;
  state: SimulationState;
  onStart: () => void;
  onPause: () => void;
  onReset: () => void;
}

const ControlPanel: React.FC<ControlPanelProps> = ({
  params,
  setParams,
  state,
  onStart,
  onPause,
  onReset
}) => {
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setParams(prev => ({ ...prev, [name]: parseFloat(value) }));
  };

  const isRunning = state === SimulationState.DISCHARGING;

  return (
    <div className="bg-black/60 border-t border-glass-border md:border md:border-glass-border md:rounded-xl p-6 backdrop-blur-xl h-full flex flex-col gap-6 relative overflow-hidden">
       {/* Decorative corner accents */}
       <div className="absolute top-0 left-0 w-3 h-3 border-t border-l border-neon-blue"></div>
       <div className="absolute top-0 right-0 w-3 h-3 border-t border-r border-neon-blue"></div>
       <div className="absolute bottom-0 left-0 w-3 h-3 border-b border-l border-neon-blue"></div>
       <div className="absolute bottom-0 right-0 w-3 h-3 border-b border-r border-neon-blue"></div>

      <div className="flex items-center justify-between">
        <h2 className="text-neon-blue font-display text-xl tracking-wider flex items-center gap-2">
          <Zap size={20} className="fill-neon-blue" /> 
          CONTROL_UNIT
        </h2>
        <div className="flex gap-2">
           {isRunning ? (
             <button onClick={onPause} className="p-2 bg-yellow-500/20 text-yellow-400 border border-yellow-500/50 rounded hover:bg-yellow-500/40 transition">
               <Pause size={20} />
             </button>
           ) : (
             <button 
                onClick={onStart} 
                disabled={state === SimulationState.COMPLETE}
                className="p-2 bg-neon-green/20 text-neon-green border border-neon-green/50 rounded hover:bg-neon-green/40 transition disabled:opacity-50 disabled:cursor-not-allowed"
             >
               <Play size={20} />
             </button>
           )}
           <button onClick={onReset} className="p-2 bg-neon-blue/20 text-neon-blue border border-neon-blue/50 rounded hover:bg-neon-blue/40 transition">
             <RefreshCw size={20} />
           </button>
        </div>
      </div>

      <div className="space-y-6 flex-1">
        {/* Voltage Control */}
        <div className="space-y-2 group">
          <div className="flex justify-between text-sm font-mono text-gray-400 group-hover:text-neon-blue transition-colors">
            <label htmlFor="initialVoltage">Initial Voltage (Vo)</label>
            <span className="text-white">{params.initialVoltage} V</span>
          </div>
          <input
            type="range"
            id="initialVoltage"
            name="initialVoltage"
            min="1"
            max="24"
            step="0.5"
            value={params.initialVoltage}
            onChange={handleChange}
            disabled={isRunning}
            className="w-full h-2 bg-gray-800 rounded-lg appearance-none cursor-pointer disabled:opacity-50 accent-neon-blue hover:accent-neon-green transition-all"
          />
        </div>

        {/* Resistance Control */}
        <div className="space-y-2 group">
          <div className="flex justify-between text-sm font-mono text-gray-400 group-hover:text-neon-purple transition-colors">
            <label htmlFor="resistance">Resistance (R)</label>
            <span className="text-white">{params.resistance} Ω</span>
          </div>
          <input
            type="range"
            id="resistance"
            name="resistance"
            min="100"
            max="10000"
            step="100"
            value={params.resistance}
            onChange={handleChange}
            disabled={isRunning}
            className="w-full h-2 bg-gray-800 rounded-lg appearance-none cursor-pointer disabled:opacity-50 accent-neon-purple hover:accent-white transition-all"
          />
        </div>

        {/* Capacitance Control */}
        <div className="space-y-2 group">
           <div className="flex justify-between text-sm font-mono text-gray-400 group-hover:text-neon-green transition-colors">
            <label htmlFor="capacitance">Capacitance (C)</label>
            <span className="text-white">{params.capacitance} µF</span>
          </div>
          <input
            type="range"
            id="capacitance"
            name="capacitance"
            min="10"
            max="1000"
            step="10"
            value={params.capacitance}
            onChange={handleChange}
            disabled={isRunning}
            className="w-full h-2 bg-gray-800 rounded-lg appearance-none cursor-pointer disabled:opacity-50 accent-neon-green hover:accent-white transition-all"
          />
        </div>

        {/* Calculated Stats */}
        <div className="mt-4 p-4 bg-black/40 rounded border border-gray-800">
           <div className="text-xs text-gray-500 uppercase tracking-widest mb-2">Physics Constants</div>
           <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="text-xs text-gray-400">Time Constant (τ)</div>
                <div className="text-lg font-mono text-neon-blue">
                  {((params.resistance * params.capacitance) / 1000000).toFixed(3)} s
                </div>
              </div>
              <div>
                <div className="text-xs text-gray-400">Max Current (Io)</div>
                <div className="text-lg font-mono text-neon-purple">
                  {(params.initialVoltage / params.resistance).toFixed(4)} A
                </div>
              </div>
              <div>
                 <div className="text-xs text-gray-400">Total Charge (Qo)</div>
                 <div className="text-lg font-mono text-neon-green">
                    {((params.capacitance * params.initialVoltage) / 1000).toFixed(2)} mC
                 </div>
              </div>
               <div>
                 <div className="text-xs text-gray-400">Est. Discharge Time (5τ)</div>
                 <div className="text-lg font-mono text-white">
                    {(5 * (params.resistance * params.capacitance) / 1000000).toFixed(2)} s
                 </div>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default ControlPanel;