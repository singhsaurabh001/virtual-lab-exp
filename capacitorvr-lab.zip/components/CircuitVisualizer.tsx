import React from 'react';
import { SimulationState } from '../types';

interface CircuitVisualizerProps {
  voltage: number;
  maxVoltage: number;
  state: SimulationState;
  resistance: number;
  capacitance: number;
}

const CircuitVisualizer: React.FC<CircuitVisualizerProps> = ({ 
  voltage, 
  maxVoltage, 
  state,
  resistance,
  capacitance
}) => {
  // Calculate visual intensity based on voltage ratio
  const intensity = Math.max(0.1, voltage / (maxVoltage || 1));
  const glowColor = `rgba(0, 243, 255, ${intensity})`;
  const electronSpeed = state === SimulationState.DISCHARGING ? (voltage / maxVoltage) * 2 : 0;
  
  // Create electron particles for animation
  const electrons = Array.from({ length: 8 }).map((_, i) => ({
    id: i,
    offset: i * (100 / 8)
  }));

  return (
    <div className="relative w-full h-64 md:h-80 bg-black/40 border border-glass-border rounded-xl backdrop-blur-md p-4 flex items-center justify-center overflow-hidden">
      {/* Background Grid */}
      <div className="absolute inset-0 opacity-20 pointer-events-none" 
           style={{ 
             backgroundImage: 'radial-gradient(#00f3ff 1px, transparent 1px)', 
             backgroundSize: '20px 20px' 
           }} 
      />
      
      <div className="absolute top-2 left-4 text-neon-blue font-display text-sm tracking-widest opacity-80">
        CIRCUIT_HOLOGRAPH // ACTIVE
      </div>

      <svg viewBox="0 0 400 200" className="w-full h-full drop-shadow-lg">
        <defs>
          <filter id="glow">
            <feGaussianBlur stdDeviation="2.5" result="coloredBlur"/>
            <feMerge>
              <feMergeNode in="coloredBlur"/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
        </defs>

        {/* Wire Path - Main Loop */}
        <path 
          d="M 50 100 L 50 50 L 350 50 L 350 150 L 50 150 L 50 100" 
          fill="none" 
          stroke="#334" 
          strokeWidth="4" 
        />
        
        {/* Active Wire Path (Glows with voltage) */}
        <path 
          d="M 50 100 L 50 50 L 350 50 L 350 150 L 50 150 L 50 100" 
          fill="none" 
          stroke={glowColor} 
          strokeWidth="2" 
          filter="url(#glow)"
          opacity={state === SimulationState.DISCHARGING || state === SimulationState.PAUSED ? 1 : 0.2}
        />

        {/* Electrons Animation */}
        {state === SimulationState.DISCHARGING && electrons.map((e) => (
          <circle key={e.id} r="3" fill="#fff" filter="url(#glow)">
            <animateMotion 
              dur={`${2 / (intensity + 0.1)}s`} 
              repeatCount="indefinite"
              path="M 50 100 L 50 50 L 350 50 L 350 150 L 50 150 L 50 100"
              keyPoints={`${e.offset/100};${(e.offset + 100)/100}`}
              keyTimes="0;1"
            />
          </circle>
        ))}

        {/* Capacitor Component */}
        <g transform="translate(50, 100)">
           {/* Vertical Plates */}
           <line x1="-15" y1="-15" x2="-15" y2="15" stroke="#fff" strokeWidth="4" />
           <line x1="15" y1="-15" x2="15" y2="15" stroke="#fff" strokeWidth="4" />
           {/* Connection lines */}
           <line x1="-15" y1="0" x2="-25" y2="0" stroke="#fff" strokeWidth="2" />
           <line x1="15" y1="0" x2="25" y2="0" stroke="#fff" strokeWidth="2" />
           
           {/* Charge buildup visualization */}
           <rect x="-15" y="-15" width="4" height="30" fill="#00f3ff" opacity={intensity} />
           <rect x="11" y="-15" width="4" height="30" fill="#ff0055" opacity={intensity} />
           
           <text x="-30" y="35" fill="#00f3ff" fontSize="12" fontFamily="Orbitron" textAnchor="middle">C</text>
           <text x="-30" y="50" fill="#aaa" fontSize="10" fontFamily="sans-serif" textAnchor="middle">{capacitance}µF</text>
        </g>

        {/* Resistor Component */}
        <g transform="translate(200, 50)">
          {/* Zigzag path */}
          <path d="M -20 0 L -15 -10 L -5 10 L 5 -10 L 15 10 L 20 0" fill="none" stroke="#fff" strokeWidth="3" />
          <text x="0" y="-20" fill="#bc13fe" fontSize="12" fontFamily="Orbitron" textAnchor="middle">R</text>
          <text x="0" y="-35" fill="#aaa" fontSize="10" fontFamily="sans-serif" textAnchor="middle">{resistance}Ω</text>
        </g>
        
        {/* Switch Component */}
        <g transform="translate(200, 150)">
           <circle cx="-15" cy="0" r="3" fill="#fff" />
           <circle cx="15" cy="0" r="3" fill="#fff" />
           <line 
            x1="-15" y1="0" 
            x2="15" y2="0" 
            stroke="#fff" 
            strokeWidth="2" 
            transform={state === SimulationState.DISCHARGING || state === SimulationState.PAUSED ? "rotate(0)" : "rotate(-30)"}
            style={{ transition: 'transform 0.3s ease' }}
            transform-origin="-15 0"
           />
           <text x="0" y="25" fill="#aaa" fontSize="10" fontFamily="sans-serif" textAnchor="middle">SW1</text>
        </g>

        {/* Voltmeter visualization */}
        <g transform="translate(350, 100)">
          <circle r="20" fill="#111" stroke="#333" strokeWidth="2" />
          <text x="0" y="5" fill="#fff" fontSize="14" fontWeight="bold" textAnchor="middle">V</text>
          <path d="M -20 0 L -30 0" stroke="#555" strokeWidth="1" strokeDasharray="2,2"/>
        </g>

      </svg>
      
      {/* Floating HUD Info */}
      <div className="absolute bottom-2 right-4 text-right font-mono text-xs text-neon-green">
        <div>FLOW_RATE: {(voltage / resistance).toFixed(4)} A</div>
        <div>FIELD_STR: {(voltage * 10).toFixed(1)} V/m</div>
      </div>
    </div>
  );
};

export default CircuitVisualizer;