import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area } from 'recharts';
import { DataPoint } from '../types';

interface DischargeChartProps {
  data: DataPoint[];
  maxTime: number;
}

const DischargeChart: React.FC<DischargeChartProps> = ({ data, maxTime }) => {
  return (
    <div className="w-full h-64 md:h-80 bg-black/40 border border-glass-border rounded-xl backdrop-blur-md p-4 flex flex-col">
       <div className="flex justify-between items-center mb-2">
         <h3 className="text-neon-purple font-display text-sm tracking-widest">REAL-TIME DATA PLOT // V(t)</h3>
         <span className="text-xs text-gray-500 font-mono">RC TIME CONSTANT TRACKING</span>
       </div>
       
       <div className="flex-1 min-h-0">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
            <defs>
              <linearGradient id="colorVoltage" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#bc13fe" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#bc13fe" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#333" />
            <XAxis 
              dataKey="time" 
              stroke="#666" 
              tick={{fill: '#888', fontSize: 10}}
              domain={[0, maxTime]}
              type="number"
              tickFormatter={(val) => val.toFixed(1)}
              label={{ value: 'Time (s)', position: 'insideBottomRight', offset: -5, fill: '#666', fontSize: 10 }}
            />
            <YAxis 
              stroke="#666" 
              tick={{fill: '#888', fontSize: 10}}
              label={{ value: 'Voltage (V)', angle: -90, position: 'insideLeft', fill: '#666', fontSize: 10 }}
            />
            <Tooltip 
              contentStyle={{ backgroundColor: '#050510', borderColor: '#bc13fe', borderRadius: '4px' }}
              itemStyle={{ color: '#bc13fe' }}
              labelStyle={{ color: '#fff' }}
              formatter={(value: number) => [value.toFixed(3) + ' V', 'Voltage']}
              labelFormatter={(label: number) => `t = ${label.toFixed(2)}s`}
            />
            <Line 
              type="monotone" 
              dataKey="voltage" 
              stroke="#bc13fe" 
              strokeWidth={2}
              dot={false}
              activeDot={{ r: 6, fill: '#fff', stroke: '#bc13fe' }}
              animationDuration={300}
              isAnimationActive={false} // Performance optimization for real-time
            />
             {/* Area under curve for visual effect */}
             <Area type="monotone" dataKey="voltage" stroke="none" fill="url(#colorVoltage)" fillOpacity={1} />
          </LineChart>
        </ResponsiveContainer>
       </div>
    </div>
  );
};

export default DischargeChart;