import { GoogleGenAI } from "@google/genai";
import { SimulationParams } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getGeminiResponse = async (
  prompt: string, 
  currentParams: SimulationParams,
  currentVoltage: number,
  history: string[] = []
): Promise<string> => {
  try {
    const systemContext = `
      You are an advanced Physics Lab Assistant named "CapacitorAI". 
      You are embedded in a virtual reality tool simulating capacitor discharge.
      Current Simulation Parameters:
      - Initial Voltage (V0): ${currentParams.initialVoltage} V
      - Resistance (R): ${currentParams.resistance} Ohms
      - Capacitance (C): ${currentParams.capacitance} Microfarads
      - Current Real-time Voltage: ${currentVoltage.toFixed(3)} V
      - Calculated Time Constant (tau): ${((currentParams.resistance * currentParams.capacitance) / 1000000).toFixed(4)} seconds.
      
      Your goal is to explain the physics concepts clearly, concisely, and with a slightly futuristic, helpful tone.
      Keep answers short (under 100 words) unless asked for a detailed derivation.
      Focus on the exponential decay relationship V(t) = V0 * e^(-t/RC).
    `;

    const model = 'gemini-2.5-flash';
    
    // Simple chat history construction
    const chat = ai.chats.create({
      model: model,
      config: {
        systemInstruction: systemContext,
      }
    });

    const result = await chat.sendMessage({
      message: prompt
    });

    return result.text || "I'm recalibrating my sensors. Please ask again.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Communication link unstable. Unable to reach the AI core.";
  }
};